<div class="col-lg-12">
    <h1 class="page-header">Blank</h1>
    <p><?php echo "mulai ".$this->code_start; ?></p>
    <p><?php echo "Beres ".$this->code_end; ?></p>
    <p><?php echo "hasil ".$this->code_finish; ?></p>
</div>
<!-- /.col-lg-12 -->